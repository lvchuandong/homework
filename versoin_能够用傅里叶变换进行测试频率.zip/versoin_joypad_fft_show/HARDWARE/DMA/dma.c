#include "dma.h"
//////////////////////////////////////////////////////////////////////////////////	 
//������ֻ��ѧϰʹ�ã�δ���������ɣ��������������κ���;
//ALIENTEKս��STM32������
//DMA ����	   
//����ԭ��@ALIENTEK
//������̳:www.openedv.com
//�޸�����:2012/9/8
//�汾��V1.0
//��Ȩ���У�����ؾ���
//Copyright(C) �������������ӿƼ����޹�˾ 2009-2019
//All rights reserved									  
//////////////////////////////////////////////////////////////////////////////////

DMA_InitTypeDef DMA_InitStructure;

u16 DMA1_MEM_LEN;//����DMAÿ�����ݴ��͵ĳ��� 	    
//DMA1�ĸ�ͨ������
//����Ĵ�����ʽ�ǹ̶���,���Ҫ���ݲ�ͬ��������޸�
//�Ӵ洢��->����ģʽ/8λ���ݿ���/�洢������ģʽ
//DMA_CHx:DMAͨ��CHx
//cpar:�����ַ
//cmar:�洢����ַ
//cndtr:���ݴ����� 
#define DAC_DHR12R1    (u32)&(DAC->DHR12R1)   //DAC DATA buff


void Wave_GPIO_Config(void)//DAC!-------PA5
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); 
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;      
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;  
        GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_4 ; 
    GPIO_SetBits(GPIOA,GPIO_Pin_4)  ;  
    GPIO_Init(GPIOA, &GPIO_InitStructure);      
}


void Wave_DAC_Config( void)
{
    DAC_InitTypeDef            DAC_InitStructure;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);
     
    DAC_StructInit(&DAC_InitStructure);    
    DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;//��ʹ�ò��η�����
    DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Disable; 
    DAC_InitStructure.DAC_Trigger = DAC_Trigger_T2_TRGO;//TIM2 Trigger
    DAC_Init(DAC_Channel_1, &DAC_InitStructure);
    DAC_Cmd(DAC_Channel_1, ENABLE);   
    DAC_DMACmd(DAC_Channel_1, ENABLE); 
}

void Wave_TIM_Config(u32 Wave1_Fre)//TIM2 Init
{
    TIM_TimeBaseInitTypeDef    TIM_TimeBaseStructure;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
    TIM_TimeBaseStructure.TIM_Prescaler = 29;   
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; 
    TIM_TimeBaseStructure.TIM_Period = Wave1_Fre;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
    TIM_SelectOutputTrigger(TIM2, TIM_TRGOSource_Update);
}
void Wave_DMA2_Config(uint16_t* wave)//DMA2
{                  
    DMA_InitTypeDef            DMA_InitStructure;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);
     
    DMA_StructInit( &DMA_InitStructure);      
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;//peripherals  to memory
    DMA_InitStructure.DMA_BufferSize = 1;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
     DMA_InitStructure.DMA_PeripheralBaseAddr = DAC_DHR12R1;
     DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)wave;

     DMA_Init(DMA2_Channel3, &DMA_InitStructure);
     DMA_Cmd(DMA2_Channel3, ENABLE);

}
void Wave_DMA1_Config(uint16_t* wave)//DMA1
{                  
    DMA_InitTypeDef            DMA_InitStructure;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
     
    DMA_StructInit( &DMA_InitStructure);      
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC ;//peripherals  to memory
    DMA_InitStructure.DMA_BufferSize = 1;
		DMA_InitStructure.DMA_M2M=DMA_M2M_Disable;  
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
     DMA_InitStructure.DMA_PeripheralBaseAddr = DMA_Mode_Circular;                                   //DMA������ѭ��ģʽ
	  DMA_InitStructure.DMA_PeripheralBaseAddr= (uint32_t)&ADC1->DR;;
     DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)wave;

     DMA_Init(DMA1_Channel1, &DMA_InitStructure);
     DMA_Cmd(DMA1_Channel1, ENABLE);
   
}
void Wave_Init(uint16_t* wave)
{
  Wave_GPIO_Config();             
  Wave_TIM_Config(11);            //72000000/3000=24000 points per second
  Wave_DAC_Config();   
  Wave_DMA1_Config(wave);	
  Wave_DMA2_Config(wave);              
  TIM_Cmd(TIM2, ENABLE);             
}

void MYDMA2_Enable(void)
{ 
	DMA_Cmd(DMA2_Channel3, DISABLE );  //�ر�USART1 TX DMA1 ��ָʾ��ͨ��      
 	DMA_SetCurrDataCounter(DMA2_Channel3,1);//DMAͨ����DMA����Ĵ�С
 	DMA_Cmd(DMA2_Channel3, ENABLE);  //ʹ��USART1 TX DMA1 ��ָʾ��ͨ�� 
}	 



















